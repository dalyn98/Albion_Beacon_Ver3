# README-frontend (부가 모듈)

- VITE_API_BASE=http://127.0.0.1:8787
- /v1/health, /v1/auth/gate, /v1/heartbeat, /v1/events/nearby
- GM UI는 권한 일치 시에만 노출(미권한은 ‘숨김’)
