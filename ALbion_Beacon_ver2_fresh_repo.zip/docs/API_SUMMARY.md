# API Summary (auto)

- Source: contracts/openapi.yaml
