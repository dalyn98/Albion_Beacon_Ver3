# Changelog

## [v0.1.0] - 2025-08-15
- Fresh init: capture/decode/identity/share skeletons
- Contracts + Docs + CI + scripts bootstrap
